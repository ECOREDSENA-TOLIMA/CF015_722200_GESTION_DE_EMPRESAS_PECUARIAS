function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6NKK4k60Kxp":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

